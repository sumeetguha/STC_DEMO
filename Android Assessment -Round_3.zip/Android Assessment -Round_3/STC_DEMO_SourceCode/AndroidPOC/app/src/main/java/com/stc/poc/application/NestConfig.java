package com.stc.poc.application;

import okhttp3.logging.HttpLoggingInterceptor;

/*
 *Class defines the URL's / Constants
 */

public class NestConfig {

    public static final String ENDPOINT = "https://api.github.com";
    public static boolean DEBUG_ENABLED = true;
    // for retrofit calls logging
    public static HttpLoggingInterceptor.Level HttpLoggingInterceptorLevel =
            HttpLoggingInterceptor.Level.BODY;
}
