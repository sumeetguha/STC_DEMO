package com.stc.poc.ui.viewmodels;

import android.content.Context;
import android.databinding.BaseObservable;
import android.databinding.ObservableBoolean;
import android.databinding.ObservableField;
import android.widget.Toast;

import com.stc.poc.apis.AccountRetroFitManager;
import com.stc.poc.data.models.User;

import java.util.ArrayList;

import rx.Subscriber;

/*
 * View Model for list of Users
 */
public class UserListViewModel extends BaseObservable {

    public interface ActionListener {
        void onDataComplted(ArrayList<User> userList);
    }

    public UserListViewModel(Context ctx, ActionListener listener) {
        this.mListener = listener;
        this.mContext = ctx;
        pageLoadingVisible.set(true);
        AccountRetroFitManager.getUser(new getUserListSubscriber());
    }


    private class getUserListSubscriber extends Subscriber<ArrayList<User>> {

        @Override
        public void onCompleted() {
        }

        @Override
        public void onError(Throwable e) {
            pageLoadingVisible.set(false);
            Toast.makeText(mContext, "Network Error", Toast.LENGTH_SHORT).show();

        }

        @Override
        public void onNext(ArrayList<User> response) {
            pageLoadingVisible.set(false);
            if (response != null) {
                if (response.size() > 0) {
                    count.set("User Count (" + response.size() + ")");
                    mList = response;
                    mListener.onDataComplted(response);
                } else {
                    noDataVisible.set(true);
                }
            } else {
                noDataVisible.set(true);
            }
        }
    }

    public ObservableBoolean pageLoadingVisible = new ObservableBoolean(false);
    public ObservableBoolean noDataVisible = new ObservableBoolean(false);
    private Context mContext;
    public ArrayList<User> mList = new ArrayList<User>();
    private ActionListener mListener;
    public ObservableField<String> count = new ObservableField<>("User Count (0)");

}
