package com.stc.poc.apis;

import com.stc.poc.application.NestConfig;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Base class used to append the END POINT URL
 */
public class BaseRetroFitManager {

    /*
     * Used for all the calls that require token in header
     */
    public static Retrofit getRetrofitForUrl() {
        return getRetrofit(URL, true);
    }

    /*
     * Only used for token calls
     */
    public static Retrofit getRetrofitForUrlNoToken() {
        return getRetrofit(URL, false);
    }

    private static Retrofit getRetrofit(String inUrl, boolean withToken) {
        Gson gson = new GsonBuilder().setLenient().create();

        Retrofit.Builder retrofitBuilder = new Retrofit.Builder()
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .addConverterFactory(GsonConverterFactory.create(gson))
                .baseUrl(inUrl);

        OkHttpClient.Builder okHttpClientBuilder = new OkHttpClient.Builder();

        if (withToken) {
            okHttpClientBuilder.addInterceptor(new Interceptor() {
                @Override
                public Response intercept(Chain chain) throws IOException {
                    Request origReq = chain.request();

                    Request.Builder requestBuilder = origReq.newBuilder()
                            //.addHeader("Authorization",
                            //       "Bearer " + TokenManager.getInstance().getAccessToken())
                            .addHeader("Content-Type", "application/json")
                            .addHeader("Accept", "application/json");

                    Request request = requestBuilder.build();

                    return chain.proceed(request);
                }
            });
        }

        // Add all the other interceptors before this
        if (NestConfig.DEBUG_ENABLED) {
            HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
            logging.setLevel(NestConfig.HttpLoggingInterceptorLevel);
            okHttpClientBuilder.addInterceptor(logging);
        }

        OkHttpClient okHttpClient = okHttpClientBuilder
                .connectTimeout(10, TimeUnit.SECONDS)
                .writeTimeout(20, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .build();
        retrofitBuilder.client(okHttpClient);

        return retrofitBuilder.build();
    }

    public static String getUuid() {
        return UUID.randomUUID().toString();
    }

    public static Map<String, String> getBaseQueryParams() {
        Map<String, String> queryParams = new LinkedHashMap<>();
        queryParams.put("test", BaseRetroFitManager.getUuid());
        return queryParams;
    }

    private static final String URL = NestConfig.ENDPOINT;
}
