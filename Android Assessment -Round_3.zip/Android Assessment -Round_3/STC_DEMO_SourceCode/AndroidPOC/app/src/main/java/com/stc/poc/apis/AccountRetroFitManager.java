package com.stc.poc.apis;

import com.stc.poc.apis.services.AccountApiService;
import com.stc.poc.data.models.User;
import com.stc.poc.data.models.UserRepo;

import java.util.ArrayList;

import rx.Observable;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

/**
 * Class used to call the API methods
 */
public class AccountRetroFitManager extends BaseRetroFitManager {

    private AccountRetroFitManager() {
    }

    //To get the user list
    public static void getUser(Subscriber<ArrayList<User>> subscriber) {
        AccountApiService accountApiService
                = getRetrofitForUrlNoToken().create(AccountApiService.class);
        Observable<ArrayList<User>> response
                = accountApiService.getUser();
        response.subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);

    }

    //To get the count of followers from the user list
    public static void getUserFollowers(final String username, Subscriber<ArrayList<User>> subscriber) {
        AccountApiService accountApiService
                = getRetrofitForUrlNoToken().create(AccountApiService.class);
        Observable<ArrayList<User>> response
                = accountApiService.getUserFollower(username);
        response.subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);

    }

    //To get the user repo list
    public static void getUserRepo(final String username, Subscriber<ArrayList<UserRepo>> subscriber) {
        AccountApiService accountApiService
                = getRetrofitForUrlNoToken().create(AccountApiService.class);
        Observable<ArrayList<UserRepo>> response
                = accountApiService.getUserRepo(username);
        response.subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);
    }

    //To get the repo forks list
    public static void getRepoForks(final String username, final String repo, Subscriber<ArrayList<UserRepo>> subscriber) {
        AccountApiService accountApiService
                = getRetrofitForUrlNoToken().create(AccountApiService.class);
        Observable<ArrayList<UserRepo>> response
                = accountApiService.getRepoForks(username, repo);
        response.subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(subscriber);
    }
}
