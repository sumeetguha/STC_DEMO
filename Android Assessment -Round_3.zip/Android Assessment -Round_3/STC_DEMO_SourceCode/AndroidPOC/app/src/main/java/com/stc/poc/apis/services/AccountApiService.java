package com.stc.poc.apis.services;

import com.stc.poc.data.models.User;
import com.stc.poc.data.models.UserRepo;

import java.util.ArrayList;

import retrofit2.http.GET;
import retrofit2.http.Path;
import rx.Observable;

/*Class defines the API services to fetch the data*/
public interface AccountApiService {

    //To get the list of users//
    @GET("/users")
    Observable<ArrayList<User>> getUser();

    //To get the count of followers from users list
    @GET("/users/{username}/followers")
    Observable<ArrayList<User>> getUserFollower(@Path("username") String username);

    //To get the list of repo users
    @GET("/users/{username}/repos")
    Observable<ArrayList<UserRepo>> getUserRepo(@Path("username") String username);

    //To get the list of repo forks
    @GET("/repos/{username}/{repo}/forks")
    Observable<ArrayList<UserRepo>> getRepoForks(@Path("username") String username, @Path("repo") String repo);

}

