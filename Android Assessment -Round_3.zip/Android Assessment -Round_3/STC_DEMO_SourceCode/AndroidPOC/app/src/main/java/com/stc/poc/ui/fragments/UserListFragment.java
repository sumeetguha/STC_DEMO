package com.stc.poc.ui.fragments;

import android.app.Activity;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.stc.poc.R;
import com.stc.poc.data.models.User;
import com.stc.poc.ui.adapter.UserListAdapter;
import com.stc.poc.ui.viewmodels.UserListViewModel;
import com.stc.poc.databinding.FragmentUserlistBinding;

import java.util.ArrayList;


/*
 *Class to show list of users page
 */

public class UserListFragment extends Fragment implements UserListViewModel.ActionListener,
        UserListAdapter.ActionListener {

    ActionListener mListener;

    public interface ActionListener {
        void onUserSelected(String username);
    }


    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            mListener = (ActionListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString() + " must implement onSomeEventListener");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_userlist, container, false);
        mViewModel = new UserListViewModel(getContext(), this);
        mBinding = DataBindingUtil.bind(view);
        mBinding.setViewModel(mViewModel);
        return view;
    }

    UserListViewModel mViewModel;
    FragmentUserlistBinding mBinding;
    UserListAdapter adapter;
    ArrayList<User> userList = null;


    @Override
    public void onDataComplted(ArrayList<User> userList) {
        this.userList = userList;
        adapter = new UserListAdapter(this.userList, getContext(), this);
        mBinding.rvList.setLayoutManager(new LinearLayoutManager(getContext()));
        mBinding.rvList.setAdapter(adapter);
    }


    @Override
    public void onUserSelected(String username) {
        mListener.onUserSelected(username);
    }
}