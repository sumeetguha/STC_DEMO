package com.stc.poc.ui.adapter;

import android.content.Context;
import android.databinding.DataBindingUtil;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.stc.poc.R;
import com.stc.poc.data.models.UserRepo;
import com.stc.poc.databinding.ItemUserRepoListBinding;

import java.util.ArrayList;

/**
 * Class defines adapter for Repo list
 */
public class UserRepoAdapter extends RecyclerView.Adapter<UserRepoAdapter.ViewHolder> {
    private ArrayList<UserRepo> dataset;
    private Context context;
    private ActionListener actionListener;


    public interface ActionListener {
        void onUserSelected(String username, String repoName);
    }


    public static class ViewHolder extends RecyclerView.ViewHolder {

        public ItemUserRepoListBinding binding;

        public ViewHolder(ItemUserRepoListBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    public UserRepoAdapter(ArrayList<UserRepo> dataset, Context context, ActionListener actionListener) {
        this.dataset = dataset;
        this.context = context;
        this.actionListener = actionListener;
    }

    @NonNull
    @Override
    public UserRepoAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        ItemUserRepoListBinding binding = DataBindingUtil.inflate(LayoutInflater.from(viewGroup.getContext()),
                R.layout.item_user_repo_list, viewGroup, false);
        return new UserRepoAdapter.ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull final UserRepoAdapter.ViewHolder viewHolder, int i) {
        final UserRepo data = dataset.get(i);
        viewHolder.binding.setDatarepo(data);
        viewHolder.binding.mainLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                actionListener.onUserSelected(data.getOwner().getLogin(), data.getName());
            }
        });
    }

    @Override
    public int getItemCount() {
        return (dataset != null) ? dataset.size() : 0;
    }


}
