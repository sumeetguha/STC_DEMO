package com.stc.poc;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.widget.Button;

import com.stc.poc.base.BaseActivity;
import com.stc.poc.ui.fragments.UserForksFragment;
import com.stc.poc.ui.fragments.UserListFragment;
import com.stc.poc.ui.fragments.UserRepoFragment;

import java.util.List;

/*
 * Class design for the initial main activity
 * */

public class MainActivity extends BaseActivity implements UserListFragment.ActionListener, UserRepoFragment.ForkedActionListener {

    Button btn;
    Fragment prevFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn = (Button) findViewById(R.id.btn);
        setDefaultScreen();
    }

    private void setDefaultScreen() {
        Fragment fragment = new UserListFragment();
        getSupportFragmentManager().beginTransaction()
                .add(R.id.fragmentHolderFullScreen, fragment)
                .commit();

    }

    private void setSelectedFragment(Fragment fragment) {
        if (fragment != null) {
            List fragments = getSupportFragmentManager().getFragments();
            prevFragment = (Fragment) fragments.get(fragments.size() - 1);
            getSupportFragmentManager().beginTransaction()
                    .hide(prevFragment)
                    .add(R.id.fragmentHolderFullScreen, fragment)
                    .addToBackStack(fragment.getClass().getSimpleName())
                    .commit();
        }
    }

    @Override
    public void onUserSelected(String username) {
        Fragment fragment = new UserRepoFragment();
        ((UserRepoFragment) fragment).setUserName(username);
        setSelectedFragment(fragment);
    }

    @Override
    public void forkUsers(String username, String repoName) {
        Fragment fragment = new UserForksFragment();
        ((UserForksFragment) fragment).setForkUserList(username, repoName);
        setSelectedFragment(fragment);
    }
}
