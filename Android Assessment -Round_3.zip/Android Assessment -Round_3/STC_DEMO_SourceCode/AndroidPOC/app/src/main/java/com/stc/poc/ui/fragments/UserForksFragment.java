package com.stc.poc.ui.fragments;

import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.stc.poc.R;
import com.stc.poc.data.models.UserRepo;
import com.stc.poc.databinding.FragmentUserforklistBinding;
import com.stc.poc.ui.adapter.UserForksAdapter;
import com.stc.poc.ui.viewmodels.UserForkViewModel;

import java.util.ArrayList;


/**
 * Class to show list of Fork Users page
 */

public class UserForksFragment extends Fragment implements UserForkViewModel.ActionListener {


    String userName;
    String repoName;
    ArrayList<UserRepo> userRepos;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_userforklist, container, false);
        mViewModel = new UserForkViewModel(getActivity(), this, userName, repoName);
        mBinding = DataBindingUtil.bind(view);
        mBinding.setViewModel(mViewModel);
        return view;
    }

    UserForksAdapter adapter;
    UserForkViewModel mViewModel;
    FragmentUserforklistBinding mBinding;

    public void setForkUserList(String userName, String repoName) {
        this.userName = userName;
        this.repoName = repoName;
    }

    @Override
    public void onDataComplted(ArrayList<UserRepo> userList) {
        adapter = new UserForksAdapter(userList, getContext());
        mBinding.rvList.setLayoutManager(new LinearLayoutManager(getContext()));
        mBinding.rvList.setAdapter(adapter);
    }
}