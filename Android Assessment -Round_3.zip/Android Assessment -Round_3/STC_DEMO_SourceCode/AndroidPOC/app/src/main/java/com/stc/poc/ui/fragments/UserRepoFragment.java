package com.stc.poc.ui.fragments;

import android.app.Activity;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.stc.poc.R;
import com.stc.poc.data.models.UserRepo;
import com.stc.poc.databinding.FragmentUserRepoBinding;
import com.stc.poc.ui.adapter.UserRepoAdapter;
import com.stc.poc.ui.viewmodels.UserReposViewModel;

import java.util.ArrayList;


/**
 * Class to show list of Repo page
 */
public class UserRepoFragment extends Fragment implements UserReposViewModel.ActionListener, UserRepoAdapter.ActionListener {

    private String username;
    private String repo;
    private ForkedActionListener mListener;

    @Override
    public void onUserSelected(String username, String repoName) {
        mListener.forkUsers(username, repoName);
    }

    public interface ForkedActionListener {
        void forkUsers(String username, String repo);
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            mListener = (ForkedActionListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString() + " must implement onSomeEventListener");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_user_repo, container, false);
        mViewModel = new UserReposViewModel(getContext(), this, username);
        mBinding = DataBindingUtil.bind(view);
        mBinding.setViewRepoModel(mViewModel);


        return view;
    }

    UserReposViewModel mViewModel;
    FragmentUserRepoBinding mBinding;
    UserRepoAdapter adapter;
    ArrayList<UserRepo> userList = null;


    @Override
    public void onDataComplted(ArrayList<UserRepo> userList) {
        this.userList = userList;
        adapter = new UserRepoAdapter(this.userList, getContext(), this);
        mBinding.rvList.setLayoutManager(new LinearLayoutManager(getContext()));
        mBinding.rvList.setAdapter(adapter);
    }

    public void setUserName(String username) {
        this.username = username;
    }
}