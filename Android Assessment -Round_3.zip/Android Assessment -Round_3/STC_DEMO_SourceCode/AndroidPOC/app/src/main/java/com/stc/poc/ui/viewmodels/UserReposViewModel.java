package com.stc.poc.ui.viewmodels;

import android.content.Context;
import android.databinding.BaseObservable;
import android.databinding.ObservableBoolean;
import android.databinding.ObservableField;
import android.widget.Toast;

import com.stc.poc.apis.AccountRetroFitManager;
import com.stc.poc.data.models.UserRepo;

import java.util.ArrayList;

import rx.Subscriber;

/*
 * View Model for list of Repo Users
 */
public class UserReposViewModel extends BaseObservable {

    public interface ActionListener {
        void onDataComplted(ArrayList<UserRepo> userList);
    }

    public UserReposViewModel(Context ctx, ActionListener listener, String username) {
        this.mListener = listener;
        this.mContext = ctx;
        pageLoadingVisible.set(true);
        AccountRetroFitManager.getUserRepo(username, new getUserRepoSubscriber());
    }


    private class getUserRepoSubscriber extends Subscriber<ArrayList<UserRepo>> {

        @Override
        public void onCompleted() {
        }

        @Override
        public void onError(Throwable e) {
            pageLoadingVisible.set(false);
            Toast.makeText(mContext, "Network Error", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onNext(ArrayList<UserRepo> response) {
            pageLoadingVisible.set(false);
            if (response != null) {
                if (response.size() > 0) {
                    count.set("User Count (" + response.size() + ")");
                    mList = response;
                    mListener.onDataComplted(response);
                } else {
                    noDataVisible.set(true);
                }
            } else {
                noDataVisible.set(true);
            }
        }
    }

    public ObservableBoolean pageLoadingVisible = new ObservableBoolean(false);
    public ObservableBoolean noDataVisible = new ObservableBoolean(false);
    private Context mContext;
    public ArrayList<UserRepo> mList = new ArrayList<UserRepo>();
    private ActionListener mListener;
    public ObservableField<String> count = new ObservableField<>("User Count (0)");

}
