package com.stc.poc.ui.adapter;

import android.content.Context;
import android.databinding.DataBindingUtil;
import android.graphics.Bitmap;
import android.support.annotation.NonNull;
import android.support.v4.graphics.drawable.RoundedBitmapDrawable;
import android.support.v4.graphics.drawable.RoundedBitmapDrawableFactory;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.stc.poc.R;
import com.stc.poc.apis.AccountRetroFitManager;
import com.stc.poc.data.models.User;

import java.util.ArrayList;

import com.stc.poc.data.models.UserRepo;
import com.stc.poc.databinding.ItemUserListBinding;
import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.BitmapImageViewTarget;

import rx.Subscriber;

/**
 * Class defines adapter for User list
 */
public class UserListAdapter extends RecyclerView.Adapter<UserListAdapter.ViewHolder> {
    private ArrayList<User> dataset;
    private Context context;
    private ActionListener actionListener;


    public interface ActionListener {
        void onUserSelected(String username);
    }


    public static class ViewHolder extends RecyclerView.ViewHolder {

        public ItemUserListBinding binding;

        public ViewHolder(ItemUserListBinding binding) {
            super(binding.getRoot());
            this.binding = binding;

            /*binding.tvWaveName.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });*/
        }
    }

    public UserListAdapter(ArrayList<User> dataset, Context context, ActionListener actionListener) {
        this.dataset = dataset;
        this.context = context;
        this.actionListener = actionListener;
    }

    @NonNull
    @Override
    public UserListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        ItemUserListBinding binding = DataBindingUtil.inflate(LayoutInflater.from(viewGroup.getContext()),
                R.layout.item_user_list, viewGroup, false);
        return new UserListAdapter.ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull final UserListAdapter.ViewHolder viewHolder, final int i) {
        final User data = dataset.get(i);
        viewHolder.binding.setData(data); //setData is the name that we have given in the layout file
        viewHolder.binding.tvFollower.setText("Follower Count: " + data.getFollower_count());
        viewHolder.binding.tvRepo.setText("Repo Count: " + data.getRepo_count());

        if (data.getExpanded()) {
            showViews(viewHolder);
        } else {
            hideViews(viewHolder);
        }

        viewHolder.binding.mainLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                actionListener.onUserSelected(data.getLogin());
            }
        });

        viewHolder.binding.icDownArr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                data.setExpanded(true);
                getTotalCounts(data.getLogin(), i);
                showViews(viewHolder);
            }
        });

        viewHolder.binding.icUpArr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                data.setExpanded(false);
                hideViews(viewHolder);
            }
        });

        Glide.with(context).load(data.getAvatarUrl()).asBitmap().centerCrop().into(new BitmapImageViewTarget(viewHolder.binding.imageView) {
            @Override
            protected void setResource(Bitmap resource) {
                RoundedBitmapDrawable circularBitmapDrawable =
                        RoundedBitmapDrawableFactory.create(context.getResources(), resource);
                circularBitmapDrawable.setCircular(true);
                viewHolder.binding.imageView.setImageDrawable(circularBitmapDrawable);
            }
        });
    }

    @Override
    public int getItemCount() {
        return (dataset != null) ? dataset.size() : 0;
    }

    public void showViews(ViewHolder viewHolder) {
        viewHolder.binding.tvFollower.setVisibility(View.VISIBLE);
        viewHolder.binding.tvRepo.setVisibility(View.VISIBLE);
        viewHolder.binding.icUpArr.setVisibility(View.VISIBLE);
        viewHolder.binding.icDownArr.setVisibility(View.GONE);
    }


    public void hideViews(ViewHolder viewHolder) {
        viewHolder.binding.tvFollower.setVisibility(View.GONE);
        viewHolder.binding.tvRepo.setVisibility(View.GONE);
        viewHolder.binding.icUpArr.setVisibility(View.GONE);
        viewHolder.binding.icDownArr.setVisibility(View.VISIBLE);
    }

    private void getTotalCounts(String username, int position) {
        AccountRetroFitManager.getUserFollowers(username, new getFollowerCount(position));
        AccountRetroFitManager.getUserRepo(username, new getRepoCount(position));
    }

    private class getFollowerCount extends Subscriber<ArrayList<User>> {
        int mPosition;

        public getFollowerCount(int mPosition) {
            this.mPosition = mPosition;
        }

        @Override
        public void onCompleted() {
        }

        @Override
        public void onError(Throwable e) {
        }

        @Override
        public void onNext(ArrayList<User> response) {
            if (response != null) {
                dataset.get(mPosition).setFollower_count(response.size());
                notifyDataSetChanged();
            }
        }
    }

    private class getRepoCount extends Subscriber<ArrayList<UserRepo>> {

        int mPosition;

        public getRepoCount(int mPosition) {
            this.mPosition = mPosition;
        }

        @Override
        public void onCompleted() {
        }

        @Override
        public void onError(Throwable e) {
        }

        @Override
        public void onNext(ArrayList<UserRepo> response) {
            if (response != null) {
                dataset.get(mPosition).setRepo_count(response.size());
                notifyDataSetChanged();
            }
        }
    }
}