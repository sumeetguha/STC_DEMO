package com.stc.poc.base;

import android.content.Context;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.stc.poc.R;


/* Base Activity Class */
public class BaseActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (isPortraitOnly(this)) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
    }
    private static boolean isPortraitOnly(Context context) {
        return context.getResources().getBoolean(R.bool.portrait_only);
    }


}
